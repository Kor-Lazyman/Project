
# learn2learn.gym

The `learn2learn.gym` interface is being re-worked and will soon be released with major improvements.

If you need those tasks now, please refer to the [code](https://github.com/learnables/learn2learn/tree/master/learn2learn/gym) and [examples](https://github.com/learnables/learn2learn/tree/master/examples/rl).


<!--
::: learn2learn.gym.MetaEnv
    selection:
      members:
        -

::: learn2learn.gym.AsyncVectorEnv
    selection:
      members:
        - __init__

## learn2learn.gym.envs.mujoco

::: learn2learn.gym.envs.mujoco.HalfCheetahForwardBackwardEnv
    selection:
      members:
        - __init__

::: learn2learn.gym.envs.mujoco.AntForwardBackwardEnv
    selection:
      members:
        - __init__

::: learn2learn.gym.envs.mujoco.AntDirectionEnv
    selection:
      members:
        - __init__

::: learn2learn.gym.envs.mujoco.HumanoidForwardBackwardEnv
    selection:
      members:
        - __init__

::: learn2learn.gym.envs.mujoco.HumanoidDirectionEnv
    selection:
      members:
        - __init__

## learn2learn.gym.envs.particles

::: learn2learn.gym.envs.particles.Particles2DEnv
    selection:
      members:
        - __init__

## learn2learn.gym.envs.metaworld

::: learn2learn.gym.envs.metaworld.MetaWorldML1
    selection:
      members:
        - __init__

::: learn2learn.gym.envs.metaworld.MetaWorldML10
    selection:
      members:
        - __init__

::: learn2learn.gym.envs.metaworld.MetaWorldML45
    selection:
      members:
        - __init__

-->

