#!/usr/bin/env python3

from .news_classification import NewsClassification
